from flask import Flask, json, make_response, jsonify, render_template, session,Response
from flask_restx import Resource, Api, reqparse
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import jwt, os, random
from flask_mail import Mail, Message
import cv2
import numpy as np
from tensorflow.keras.models import model_from_json  
from tensorflow.keras.preprocessing import image 
from keras.models import load_model
from tensorflow.keras.utils import img_to_array
from collections import defaultdict
import time

app = Flask(__name__) 

face_classifier = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
classifier = load_model('model.h5')
emotion_labels = ['Angry', 'Disgust', 'Fear', 'Happy', 'Neutral', 'Sad', 'Surprise']

cap = cv2.VideoCapture(2)

def gen_frames():  # generate frame by frame from camera
    counter = 0
    emotions_count = defaultdict(int)  # Menyimpan jumlah deteksi emosi

    while True:
        _, frame = cap.read()
        labels = []
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_classifier.detectMultiScale(gray)

        for (x, y, w, h) in faces:
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 255), 2)
            roi_gray = gray[y:y+h, x:x+w]
            roi_gray = cv2.resize(roi_gray, (48, 48), interpolation=cv2.INTER_AREA)

            if np.sum([roi_gray]) != 0:
                roi = roi_gray.astype('float') / 255.0
                roi = img_to_array(roi)
                roi = np.expand_dims(roi, axis=0)

                prediction = classifier.predict(roi)[0]
                label = emotion_labels[prediction.argmax()]
                label_position = (x, y)
                cv2.putText(frame, label, label_position, cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                # Menghitung jumlah deteksi emosi
                emotions_count[label] += 1

                # Kirim data ke klien melalui server-sent events
                yield f"data: {json.dumps(emotions_count)}\n\n"

            else:
                cv2.putText(frame, 'No Faces', (30, 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        _, jpeg = cv2.imencode('.jpg', frame)
        frame_bytes = jpeg.tobytes()

        # Simpan gambar setiap 2 detik
        if counter % 20 == 0:
            filename = f'frame_{counter}.jpg'
            path = f'history/{filename}'  # Ganti dengan path folder Anda
            with open(path, 'wb') as f:
                f.write(frame_bytes)

        counter += 1
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n\r\n')
        time.sleep(0.1)  # Tunggu 0.1 detik sebelum mengambil frame berikutnya

        # Print jumlah deteksi emosi setiap 10 detik
        if counter % 200 == 0:
            print(f'Emotion Count: {emotions_count}')


@app.route('/video_feed')
def video_feed():
    #Video streaming route. Put this in the src attribute of an img tag
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')


@app.route('/realtime')
def real():
    return render_template('index.html')

@app.route('/history')
def history():
    # emotions_count = defaultdict(int)  # Menyimpan jumlah deteksi emosi

    # def update_emotion_count():
    #     while True:
    #         # Dapatkan jumlah deteksi emosi dari generator frames
    #         time.sleep(10)
    #         yield f"data: {json.dumps(emotions_count)}\n\n"

    return Response(gen_frames(), mimetype='text/event-stream')


    
# @app.route('/real')
# def real():
#     return render_template('index.html')
    
if __name__ == '__main__':
    # app.run(ssl_context='adhoc', debug=True)
    app.run(host='0.0.0.0' , debug=True)