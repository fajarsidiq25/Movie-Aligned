# api ,lariii adaa apii

clone repo
`git clone https://github.com/muhammadisa07/api`
